package Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DBQuery {

    public Connection con = null;
    public Statement st = null;
    public ResultSet rs = null;
    private String name;
    private String email;
    private String phone;
    private String add;
    private String state;
    private String city;
    
    private String uname;
    private String h_id;
    private String hname;
    private String ph_no;
    private String mc_id;
    private String mn_name;
    private String mc_add;
    private String pass;
    private String q;
    private String password;
    private String utype;
    private ResultSet d;

    public int addhospData(int id, String name, String email, int phone, String area, String add, String state, String city, int lon, int lat, String password) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String q1 = "insert into hospital_list values ('" + id + "','" + name + "','" + email + "','" + phone + "','" + area + "','" + add + "','" + state + "','" + city + "','" + lon + "','" + lat + "')";
        System.out.println(">>" + q1);
        st = con.createStatement();
        String q = "insert into login values('" + email + "','" + password + "','hospital')";
        System.out.println("" + q1);
        i = st.executeUpdate(q1);
        st.executeUpdate(q);
        return i;
    }
 public int add_lab_assistance(String hid,String fname,String lname,  String phone, String pass,String email) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String q1 = "insert into lab_assistant_details set hid='"+hid+"', fname='" + fname + "',lname='" + lname + "',mobile='" + phone + "', pass='"+pass+"',email='"+email+"'";
        System.out.println(">>" + q1);
        st = con.createStatement();
        String q = "insert into login values('" + phone + "','" + pass + "','lab_assitant')";
        System.out.println("" + q1);
        i = st.executeUpdate(q1);
        st.executeUpdate(q);
        return i;
    }



    

    public int addUserData(String hid,String fname, String lname, String phone,String email, String add, String doctorID, String group, String admDate,  String password) throws SQLException, ClassNotFoundException {
       
        
        int i = 0;
        try{
        
        con = DBConnection.getConnection();
        String p = "insert into patient_registration(hid,fname, lname, phone_no, email,address, consulting_doctor_id, blood_group, admission_date,  password) values ('"+hid+"','"
                 + fname + "','" + lname + "','" + phone + "','"+email+"','" + add + "','" + doctorID + "','" + group + "','" +admDate+"' ,'" + password + "')";
        System.out.println(">>" + p);
        st = con.createStatement();
        //String l = "insert into login values('" + email + "','" + password + "','user')";
        //System.out.println("" + p);
        i = st.executeUpdate(p);
        String q1="select MAX(patient_id) from patient_registration";
        System.out.println(">>"+q1);
        rs=st.executeQuery(q1);
        if(rs.next())
        {
        i=rs.getInt(1);
        
        }
        //st.executeUpdate(l);
        
    }catch(Exception e)
    {
    e.printStackTrace();
    }
        return i;
    }
    

    

    public int addMedicines(String medicine_Name, int amount, int quantity) throws ClassNotFoundException, SQLException{
        int i = 0;
        con = DBConnection.getConnection();
        String qry = "insert into medicine_info(medicine_name, price, quantity_available) values('" + medicine_Name + "','" + amount + "','" + quantity + "')";
        st = con.createStatement();
        i = st.executeUpdate(qry);
        return i;
    }
    

    public ArrayList[] get_doctors_info() throws ClassNotFoundException, SQLException{
        ArrayList al_ids=new ArrayList();
        ArrayList al_names=new ArrayList();
        ArrayList al_emails=new ArrayList();
        
        ArrayList al_mob=new ArrayList();
        ArrayList al[]=new ArrayList[4];
       
        String qry2 = "select * from doctor_reg";
         
          
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al_ids.add(rs2.getInt("doctor_id"));
             al_names.add(rs2.getString("fname")+" "+rs2.getString("lname"));
             al_emails.add(rs2.getString("email_id"));
             al_mob.add(rs2.getString("mobile_no"));
          }
          al[0]=al_ids;
          al[1]=al_names;
          al[2]=al_emails;
          al[3]=al_mob;
          return al;
    }
    public ArrayList[] get_lab_assistant_info() throws ClassNotFoundException, SQLException{
        ArrayList al_id=new ArrayList();
        ArrayList al_fnames=new ArrayList();
        ArrayList al_lnames=new ArrayList();
        ArrayList al_emails=new ArrayList();
        
        ArrayList al_mob=new ArrayList();
        ArrayList al[]=new ArrayList[5];
       
        String qry2 = "select * from lab_assistant_details";
         
          
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al_id.add(rs2.getString("id"));
             al_fnames.add(rs2.getString("fname"));
             al_lnames.add(rs2.getString("lname"));
             al_emails.add(rs2.getString("email"));
             al_mob.add(rs2.getString("mob"));
          }
          al[0]=al_id;
          al[1]=al_fnames;
          al[2]=al_lnames;
          al[3]=al_emails;
          al[4]=al_mob;
          return al;
    }
    
    


    
    public int getLabTestCount() throws ClassNotFoundException, SQLException{
        String qry = "select count(*) from lab_test_registration";
        int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
        
          return count;
    }

    
    public int docReg(String hid,String fname, String lname, String email, String mobNo, String gender, String addr, String qlf, String password) throws ClassNotFoundException, SQLException{
        int i = 0;
        String qry = "insert into doctor_reg(hid,fname, lname, email_id, mobile_no, gender, address, qualifications, password) values('"+hid+"','" + fname + "','" + lname + "','" + email + "','" + mobNo + "','" + gender + "','" + addr + "','" + qlf + "','" + password + "')";
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        return i;
    }
     public int add_hospital(String hname, String email, String mob,  String addr, String pass) throws ClassNotFoundException, SQLException{
        int i = 0;
        String qry = "insert into hospital_details set hname='"+hname+"', email='"+email+"', mob='"+mob+"',address='"+addr+"'";
      
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        int hid=get_max_hid();
         System.out.println("hid="+hid);
        String qry1= "insert into login values('"+hid+"','"+pass+"', 'hospital')";
        st.executeUpdate(qry1);
        return hid;
    }
      public int get_max_hid() throws ClassNotFoundException, SQLException{
        
        String qry1 = "select MAX(hid) from hospital_details";
       
          int id = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              id = rs1.getInt(1);
          }
       
          
          return id;
    }
    public int[] getDocIds(String hid) throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from doctor_reg where hid='"+hid+"'";
        String qry2 = "select doctor_id from doctor_reg where hid='"+hid+"'";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] docIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getInt("doctor_id");
          }
          
          return docIDArr;
    }
     public String[] getDocNames(String hid) throws ClassNotFoundException, SQLException{
         
        
        String qry1 = "select count(*) from doctor_reg where hid='"+hid+"'";
        String qry2 = "select * from doctor_reg where hid='"+hid+"'";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          String[] docIDArr = new String[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getString("fname")+" "+rs2.getString("lname");
          }
          
          return docIDArr;
    }
    public int[] getPatIds(String did) throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from patient_registration where consulting_doctor_id like '%"+did+"%'";
        String qry2 = "select patient_id from patient_registration where consulting_doctor_id like '%"+did+"%'";
        System.out.println(qry2);
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] docIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getInt("patient_id");
          }
          System.out.println(".."+docIDArr.length);
          return docIDArr;
    }
    public int[] getPatIds() throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from patient_registration";
        String qry2 = "select patient_id from patient_registration";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] docIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              docIDArr[k++] = rs2.getInt("patient_id");
          }
          
          return docIDArr;
    }
    public int[] getLabTestIDs() throws ClassNotFoundException, SQLException{
        String qry1 = "select count(*) from lab_test_registration";
        String qry2 = "select lab_test_id from lab_test_registration";
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] labTestArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              labTestArr[k++] = rs2.getInt("lab_test_id");
          }
          
          return labTestArr;
    }

 
    public String validatePass(String id, String pass) throws ClassNotFoundException, SQLException{
        String qry = "select * from doctor_reg where doctor_id =  '"+id+"'  and password='"+pass+"'";
        System.out.println("****"+qry);
        con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
          String hid="";
          int res = 0;
          
          if(rs.next()){
             
              
              hid = rs.getString("hid");
          }
          rs.close();
          
          
          
          return hid;
    }
    public String validate_patient(String id, String pass) throws ClassNotFoundException, SQLException{
        String qry = "select * from patient_registration where patient_id =  '"+id+"'  and password='"+pass+"'";
        System.out.println("****"+qry);
        con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
          String hid="";
          int res = 0;
          
          if(rs.next()){
             
              
              hid = rs.getString("hid");
          }
          rs.close();
          
          
          
          return hid;
    }
    public int[] getPatientInfo(int doc_id) throws ClassNotFoundException, SQLException{
        
        String qry1 = "select count(*) from patient_registration where consulting_doctor_id = " + doc_id;
        String qry2 = "select patient_id from patient_registration where consulting_doctor_id = " + doc_id;
        
          int count = 0;
          
          con = DBConnection.getConnection();
          st = con.createStatement();
          ResultSet rs1 = st.executeQuery(qry1);
          if(rs1.next()){
              count = rs1.getInt(1);
          }
          rs1.close();
          
          int[] patientIDArr = new int[count];
          int k = 0;
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
              patientIDArr[k++] = rs2.getInt("patient_id");
          }
          
          return patientIDArr; 
    }
    
    public String[] getPatientRep(String hid,String patient_id) throws ClassNotFoundException, SQLException{
       
        String qry = "select * from patient_registration where hid='"+hid+"' and patient_id = " + patient_id;
        
          con = DBConnection.getConnection();
           st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
          
          String name      = "";
          String phone_no = "";
          String email     = "";
          String bloodGrp  = "";
          String admDate   = "";
       
          
          while(rs.next()){
              String fname = rs.getString("fname");
              String lname = rs.getString("lname");
              name  = fname + " " + lname;
              phone_no  = rs.getString("phone_no");
              email  = rs.getString("email");
              bloodGrp  = rs.getString("blood_group");
              admDate  = rs.getString("admission_date");
           
          }
          rs.close();
          
          String[] patientRep = {name,phone_no,email, bloodGrp,  admDate}; 
          return patientRep;
    }
    
    public String getDoctorName(int docID) throws ClassNotFoundException, SQLException{
        String qry = "select fname, lname from doctor_reg where doctor_id = " + docID;
        
        con = DBConnection.getConnection();
           st = con.createStatement();
          ResultSet rs = st.executeQuery(qry);
           String name = "";
          
          while(rs.next()){
              String fname = rs.getString("fname");
              String lname = rs.getString("lname");
              name = fname + " " + lname;
          }
          rs.close();
          return name;
    }
    
    public int add_report_details(String hid,String pid, String rid, String uploaded_by, String emp_id,String dtime) throws ClassNotFoundException, SQLException{
        int i = 0;
        
        String qry = "insert into report_details values ('" + hid + "','" + pid + "','" + rid + "','" + uploaded_by + "','" + emp_id + "','" + dtime + "')";   
        System.out.println(qry);
          con = DBConnection.getConnection();
           st = con.createStatement();
            i = st.executeUpdate(qry);
           
            return i;
    }
     
     
     
     // **
    public String loginCheck(String email, String password) throws SQLException, ClassNotFoundException {
        String i = "";//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select utype from login where user_id='" + email + "' and password='" + password + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        while (rs.next()) {
            i = rs.getString("utype");
        }
        return i;
    }
     public String get_hid(String lab) throws SQLException, ClassNotFoundException {
        String i = "";//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select hid from lab_assistant_details where mobile='" + lab + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        while (rs.next()) {
            i = rs.getString("hid");
        }
        return i;
    }
   public int PloginCheck(String pid, String password) throws SQLException, ClassNotFoundException {
        int i = 0;//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select * from patient_registration  where patient_id='" + pid + "' and password='" + password + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        if (rs.next()) {
            i=1;
        }
        return i;
    }


    public ResultSet get_hospital_area(String area) throws ClassNotFoundException, SQLException {
        ArrayList al = new ArrayList();

        con = DBConnection.getConnection();
        String l = "select * from hospital_list where area='" + area + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        return rs;
    }

    public String get_hospital_list(String area) throws ClassNotFoundException, SQLException {
        ArrayList al = new ArrayList();
        String d = "";
        con = DBConnection.getConnection();
        String l = "select * from hospital_list where area='" + area + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        while (rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("name");
            String email = rs.getString("email");
            String phone = rs.getString("phone");
            String areas = rs.getString("area");
            String add = rs.getString("add");
            String state = rs.getString("state");
            String city = rs.getString("city");
            String lon = rs.getString("lon");
            String lat = rs.getString("lat");


            d += id + "-" + name + "-" + email + "-" + phone + "-" + areas + "-" + add + "-" + state + "-" + city + "-" + lon + "-" + lat + "##";

        }

        return d;
    }


    public int getIdOfHospital(String usermailid) throws ClassNotFoundException, SQLException {
        int i = 0;

        con = DBConnection.getConnection();
        String l = "select * from hospital_list where email='" + usermailid + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        if (rs.next()) {
            i = rs.getInt("id");
        }
        System.out.println("Id for hospital--" + i);
        return i;
    }

public ArrayList get_pid_list(String hid) throws ClassNotFoundException, SQLException {
        int i = 0;
        ArrayList al=new ArrayList();

        con = DBConnection.getConnection();
        String l = "select * from patient_registration where hid='" + hid + "'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        while (rs.next()) {
            i = rs.getInt("patient_id");
            al.add(i);
        }
        System.out.println("Id for hospital--" + i);
        return al;
    }
 public ArrayList get_patient_details(String hid,String pid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from patient_registration where hid='"+hid+"' and patient_id='"+pid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          if(rs2.next()){
             al.add(rs2.getString("fname"));
             al.add(rs2.getString("lname"));
             al.add(rs2.getString("phone_no"));
             al.add(rs2.getString("email"));
             al.add(rs2.getString("address"));
             al.add(rs2.getString("consulting_doctor_id"));
             al.add(rs2.getString("blood_group"));
             al.add(rs2.getString("admission_date"));
             al.add(rs2.getString("email"));
             
             
          }
          
          return al;
    }
 
 
 public ArrayList get_my_details(String hid,String pid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from report_details where hid='"+hid+"' and pid='"+pid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getString("report_id")+"##"+rs2.getString("uploaded_by")+"##"+rs2.getString("emp_id")+"##"+rs2.getString("upload_date"));
             
            
             
             
          }
          
          return al;
    }
 public int add_request(String hid, String did, String pid, String rid) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String q1 = "insert into key_request values ('" + hid + "','" + did + "','" + pid + "','" + rid + "')";
        System.out.println(">>" + q1);
        st = con.createStatement();
        
        st.executeUpdate(q1);
        return i;
    }
 public ArrayList get_my_key_request(String hid,String pid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from key_request where hid='"+hid+"' and pid='"+pid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          if(rs2.next()){
             al.add(rs2.getString("hid")+"##"+rs2.getString("did")+"##"+rs2.getString("rid"));
             
            
             
             
          }
          
          return al;
    }
 public ArrayList get_doc_details(String hid,String did) throws ClassNotFoundException, SQLException {
        int i = 0;
        ArrayList al=new ArrayList();

        con = DBConnection.getConnection();
        String l = "select * from doctor_reg where hid='" + hid + "' and doctor_id='"+did+"'";
        System.out.println(">>" + l);
        st = con.createStatement();
        rs = st.executeQuery(l);
        while (rs.next()) {
            
            al.add(rs.getString("fname"));
            al.add(rs.getString("lname"));
            al.add(rs.getString("email_id"));
            al.add(rs.getString("mobile_no"));
        }
       
        return al;
    }
 
 
 
   public int add_fund_details(String hid, String pid, String tid,  String expected_amount,String treatment_name,String Medicine_Charge, String Hospital_Charge, String Other_Treatemnt,  String Doctor_Charge,String Surgery,String predicted_amount,String to_account,String selected_hospital) throws ClassNotFoundException, SQLException{
        int i = 0;
        
        
        String pattern = "dd-MM-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String tdate = simpleDateFormat.format(new Date());
        System.out.println(tdate);

        String  pattern1 = "hh-mm-ss";
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

        String tdate1 = simpleDateFormat1.format(new Date());
        tdate1=tdate1.replace(":", "-");
        System.out.println(tdate1);
        String qry = "insert into fund_request_details set hid='"+hid+"', pid='"+pid+"',selected_hospital='"+selected_hospital+"', tid='"+tid+"',expected_amount='"+expected_amount+"',rdate='"+tdate+"',rtime='"+tdate1+"',status='pending',predicted_amount='"+predicted_amount+"',treatment_name='"+treatment_name+"',Medicine_Charge='"+Medicine_Charge+"',Hospital_Charge='"+Hospital_Charge+"',Other_Treatemnt='"+Other_Treatemnt+"',Surgery='"+Surgery+"',Doctor_Charge='"+Doctor_Charge+"',to_account='"+to_account+"'";
       System.out.println(qry);
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        String q1="select MAX(rid) from fund_request_details";
        rs=st.executeQuery(q1);
        if(rs.next())
        {
        i=rs.getInt(1);
        }
      
        return i;
    }
   public int add_ngo_fund_details(String nid,   String category,String expected_amount,String status,  String to_account) throws ClassNotFoundException, SQLException{
        int i = 0;
        
        
        String pattern = "dd-MM-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String tdate = simpleDateFormat.format(new Date());
        System.out.println(tdate);

        String  pattern1 = "hh-mm-ss";
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

        String tdate1 = simpleDateFormat1.format(new Date());
        tdate1=tdate1.replace(":", "-");
        System.out.println(tdate1);
        String qry = "insert into ngo_fund_request_details set ngo_id='"+nid+"', category='"+category+"', expected_amount='"+expected_amount+"',rdate='"+tdate+"',rtime='"+tdate1+"',status='"+status+"',to_account='"+to_account+"'";
       System.out.println(qry);
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        String q1="select MAX(rid) from ngo_fund_request_details";
        rs=st.executeQuery(q1);
        if(rs.next())
        {
        i=rs.getInt(1);
        }
      
        return i;
    }
    public ArrayList get_fund_details() throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from fund_request_details where status<>'closed'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("rid")+"#"+rs2.getInt("hid")+"#"+rs2.getInt("pid")+"#"+rs2.getInt("tid")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("treatment_name")+"#"+rs2.getString("Medicine_Charge")+"#"+rs2.getString("Hospital_Charge")+"#"+rs2.getString("Other_Treatemnt")+"#"+rs2.getString("Doctor_Charge")+"#"+rs2.getString("Surgery")+"#"+rs2.getString("predicted_amount")+"#"+rs2.getString("to_account"));
             
     
             
          }
          
          return al;
    }
     public ArrayList get_ngo_fund_details() throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from ngo_fund_request_details where status='approved'"; 
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("rid")+"#"+rs2.getString("ngo_id")+"#"+rs2.getString("category")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("to_account"));
             
     
             
          }
          
          return al;
    }
      public ArrayList get_all_ngo_fund_details() throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from ngo_fund_request_details "; 
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("rid")+"#"+rs2.getString("ngo_id")+"#"+rs2.getString("category")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("to_account"));
             
     
             
          }
          
          return al;
    }
      public ArrayList get_myngo_fund_details_rid(String rid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from ngo_fund_request_details where rid='"+rid+"'"; 
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("rid")+"#"+rs2.getString("ngo_id")+"#"+rs2.getString("category")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("to_account"));
             
     
             
          }
          
          return al;
    }
      public ArrayList get_myngo_fund_details_nid(String nid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from ngo_fund_request_details where ngo_id='"+nid+"'"; 
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("rid")+"#"+rs2.getString("ngo_id")+"#"+rs2.getString("category")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("to_account"));
             
     
             
          }
          
          return al;
    }
      
      
     public String get_fund_details(String rid) throws ClassNotFoundException, SQLException{
        String det="";
        
       
        String qry2 = "select * from fund_request_details where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             det=rs2.getInt("rid")+"#"+rs2.getInt("hid")+"#"+rs2.getInt("pid")+"#"+rs2.getInt("tid")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("treatment_name")+"#"+rs2.getString("Medicine_Charge")+"#"+rs2.getString("Hospital_Charge")+"#"+rs2.getString("Other_Treatemnt")+"#"+rs2.getString("Doctor_Charge")+"#"+rs2.getString("Doctor_Charge")+"#"+rs2.getString("Doctor_Charge")+"#"+rs2.getString("to_account");
             
     
             
          }
          
          return det;
    }
     
      public String get_ngo_fund_details(String rid) throws ClassNotFoundException, SQLException{
        String det="";
        
       
        String qry2 = "select * from ngo_fund_request_details where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             det=rs2.getInt("rid")+"#"+rs2.getString("ngo_id")+"#"+rs2.getString("category")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+rs2.getString("to_account");
             
     
             
          }
          
          return det;
    }
      
      
      
     public double get_collected_fund_details(String rid) throws ClassNotFoundException, SQLException{
        double colelcted_fund=0;
        
       
        String qry2 = "select * from collected_fund where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             colelcted_fund+=Double.parseDouble(rs2.getString("amount"));
             
     
             
          }
          
          return colelcted_fund;
    }
     
     
         public double get_ngo_collected_fund_details(String rid) throws ClassNotFoundException, SQLException{
        double colelcted_fund=0;
        
       
        String qry2 = "select * from ngo_collected_fund where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             colelcted_fund+=Double.parseDouble(rs2.getString("amount"));
             
     
             
          }
          
          return colelcted_fund;
    }
         public int update_ngo_fund_status(String rid , String status) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
      
        st = con.createStatement();
        
       
        String q3="update ngo_fund_request_details set status='"+status+"' where rid='" + rid + "'";
        st.executeUpdate(q3);
        
        
       
        
        return i;
    }   
         
         
     public int add_fund(String rid, String to_account, String from_account, String amount,String name,String mobile,String email,String hash) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String det=get_fund_details(rid);
        String a[]=det.split("#");
        
        
        double colelcted_fund=get_collected_fund_details(rid);
        colelcted_fund=colelcted_fund+Double.parseDouble(amount);
        
        String q1 = "insert into collected_fund set rid='" + rid + "',to_account='" + to_account + "',from_account='" + from_account + "',amount='" + amount + "',name='"+name+"',mobile='"+mobile+"',email='"+email+"',target_amount='"+a[4]+"',reached_amount='"+colelcted_fund+"',hash='"+hash+"'";//        String q1 = "insert into collected_fund set rid='" + rid + "',to_account='" + to_account + "',from_account='" + from_account + "',amount='" + amount + "',name='"+name+"',mobile='"+mobile+"',email='"+email+"',target_amount='"+a[4]+"',reached_amount='"+colelcted_fund+"'";//

        System.out.println(">>" + q1);
        st = con.createStatement();
        
        st.executeUpdate(q1);
        
        if(colelcted_fund>=Double.parseDouble(a[4]))
        {
        String q3="update fund_request_details set status='closed' where rid='" + rid + "'";
        st.executeUpdate(q3);
        }
        
        String q2="select MAX(transaction_id) from collected_fund";
        rs=st.executeQuery(q2);
        if(rs.next())
        {
        i=rs.getInt(1);
        }
        
        return i;
    }
     
     public int add_ngo_fund(String rid, String to_account, String from_account, String amount,String name,String mobile,String email) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String det=get_ngo_fund_details(rid);
        String a[]=det.split("#");
        
        
        double colelcted_fund=get_ngo_collected_fund_details(rid);
        colelcted_fund=colelcted_fund+Double.parseDouble(amount);
        
        String q1 = "insert into ngo_collected_fund set rid='" + rid + "',to_account='" + to_account + "',from_account='" + from_account + "',amount='" + amount + "',name='"+name+"',mobile='"+mobile+"',email='"+email+"',target_amount='"+a[3]+"',reached_amount='"+colelcted_fund+"'";
        System.out.println(">>" + q1);
        st = con.createStatement();
        
        st.executeUpdate(q1);
        
        if(colelcted_fund>=Double.parseDouble(a[3]))
        {
        String q3="update ngo_fund_request_details set status='closed' where rid='" + rid + "'";
        st.executeUpdate(q3);
        }
        
        String q2="select MAX(transaction_id) from ngo_collected_fund";
        rs=st.executeQuery(q2);
        if(rs.next())
        {
        i=rs.getInt(1);
        }
        
        return i;
    }
     
     
    public ArrayList get_fund_collected_details(String rid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from collected_fund where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("transaction_id")+"#"+rs2.getString("to_account")+"#"+rs2.getString("from_account")+"#"+rs2.getString("amount")+"#"+rs2.getString("name")+"#"+rs2.getString("mobile")+"#"+rs2.getString("email")+"#"+rs2.getString("target_amount")+"#"+rs2.getString("reached_amount"));
             
     
             
          }
          
          return al;
    }
    public ArrayList get_ngo_fund_collected_details(String rid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from ngo_collected_fund where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("transaction_id")+"#"+rs2.getString("to_account")+"#"+rs2.getString("from_account")+"#"+rs2.getString("amount")+"#"+rs2.getString("name")+"#"+rs2.getString("mobile")+"#"+rs2.getString("email")+"#"+rs2.getString("target_amount")+"#"+rs2.getString("reached_amount"));
             
     
             
          }
          
          return al;
    }
    public String track_fund(String tid) throws ClassNotFoundException, SQLException{
       String det="";
        
       int rid=0;
        String qry2 = "select * from collected_fund where transaction_id='"+tid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          if(rs2.next()){
              rid=rs2.getInt("rid");
             det=rid+"#"+rs2.getInt("transaction_id")+"#"+rs2.getString("to_account")+"#"+rs2.getString("from_account")+"#"+rs2.getString("amount")+"#"+rs2.getString("name")+"#"+rs2.getString("mobile")+"#"+rs2.getString("email")+"#"+rs2.getString("target_amount")+"#"+rs2.getString("reached_amount")+"#"+rs2.getString("hash");
             
     
             
          }
          double colelcted_fund=get_collected_fund_details(rid+"");
          System.out.println("colelcted_fund="+colelcted_fund);
          det+="#"+colelcted_fund;
          System.out.println(det);
          return det;
    }
    
    public int add_fund_details1(String hid, String pid, String tid,  String expected_amount,String treatment_name,String Medicine_Charge, String Hospital_Charge, String Other_Treatemnt,  String Doctor_Charge,String Surgery,String predicted_amount,String to_account) throws ClassNotFoundException, SQLException{
        int i = 0;
        
        
        String pattern = "dd-MM-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String tdate = simpleDateFormat.format(new Date());
        System.out.println(tdate);

        String  pattern1 = "hh-mm-ss";
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

        String tdate1 = simpleDateFormat1.format(new Date());
        tdate1=tdate1.replace(":", "-");
        System.out.println(tdate1);
        String qry = "insert into fund_request_details set hid='"+hid+"', pid='"+pid+"', tid='"+tid+"',expected_amount='"+expected_amount+"',rdate='"+tdate+"',rtime='"+tdate1+"',status='pending',predicted_amount='"+predicted_amount+"',treatment_name='"+treatment_name+"',Medicine_Charge='"+Medicine_Charge+"',Hospital_Charge='"+Hospital_Charge+"',Other_Treatemnt='"+Other_Treatemnt+"',Surgery='"+Surgery+"',Doctor_Charge='"+Doctor_Charge+"',to_account='"+to_account+"'";
       System.out.println(qry);
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        String q1="select MAX(rid) from fund_request_details";
        rs=st.executeQuery(q1);
        if(rs.next())
        {
        i=rs.getInt(1);
        }
      
        return i;
    }
   public ArrayList get_email() throws ClassNotFoundException, SQLException{
       
        ArrayList al_emails=new ArrayList();
        
       
       
        String qry2 = "select distinct email from collected_fund";
         
          
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             
             al_emails.add(rs2.getString("email"));
           
          }
         
          return al_emails;
    }
  public int add_ngo(String ngo_name, String ngo_mob,  String ngo_email,String ngo_acno,String ngo_address, String ngo_pass) throws ClassNotFoundException, SQLException{
        int i = 0;
        
      
        String qry = "insert into ngo_details set ngo_name='"+ngo_name+"', ngo_mob='"+ngo_mob+"', ngo_email='"+ngo_email+"',ngo_acno='"+ngo_acno+"',ngo_address='"+ngo_address+"',ngo_pass='"+ngo_pass+"'";
       System.out.println(qry);
        con = DBConnection.getConnection();
        st  = con.createStatement();
        i   = st.executeUpdate(qry);
        System.out.println("Query = " + qry);
        String q1="select MAX(ngo_id) from ngo_details";
        rs=st.executeQuery(q1);
        if(rs.next())
        {
        i=rs.getInt(1);
        }
      
        return i;
    }
  public int ngo_loginCheck(String ngo_id, String password) throws SQLException, ClassNotFoundException {
        int i = 0;//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select * from ngo_details where ngo_id='" + ngo_id + "' and ngo_pass='" + password + "'";
        System.out.println(">>" + p);
        st = con.createStatement();

        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        if (rs.next()) {
           i=1;
        }
        return i;
    }
  
  public int add_ngo_spent_details(String rid, String nid, String spend_for, String amount,String amount_remaining,String hash) throws SQLException, ClassNotFoundException {
        int i = 0;
        con = DBConnection.getConnection();
        String pattern = "dd-MM-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String tdate = simpleDateFormat.format(new Date());
        System.out.println(tdate);

        String  pattern1 = "hh-mm-ss";
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

        String tdate1 = simpleDateFormat1.format(new Date());
        tdate1=tdate1.replace(":", "-");
        System.out.println(tdate1);
        String q1 = "insert into ngo_spend_details values ('" + rid + "','" + nid + "','" + spend_for + "','" + amount + "','" + tdate + "','" + tdate1 + "','" + amount_remaining + "','" + hash + "')";
        System.out.println(">>" + q1);
        st = con.createStatement();
        i=st.executeUpdate(q1);
        
        return i;
    }
   public double get_ngo_spent_details(String rid, String nid) throws SQLException, ClassNotFoundException {
        double i = 0;//decliration of integer i
        con = DBConnection.getConnection();// it provide DB connection
        String p = "select * from ngo_spend_details where rid='" + rid + "' and ngo_id='" + nid + "'";
        System.out.println(">>" + p);
        st = con.createStatement();
                                            
        System.out.println("" + p);
        ResultSet rs = st.executeQuery(p);
        while (rs.next()) {
           i=i+Double.parseDouble(rs.getString("amount"));
        }
        return i;
    }
  public ArrayList get_ngo_fund_spent_details(String rid) throws ClassNotFoundException, SQLException{
        ArrayList al=new ArrayList();
        
       
        String qry2 = "select * from ngo_spend_details where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             al.add(rs2.getInt("ngo_id")+"#"+rs2.getString("used_for")+"#"+rs2.getString("amount_remaining")+"#"+rs2.getString("tdate")+"#"+rs2.getString("ttime")+"#"+rs2.getString("amount"));
             
     
             
          }
          
          return al;
    }
    public String track_ngo_fund(String rid) throws ClassNotFoundException, SQLException{
       String det="";
        
       
        String qry2 = "select * from ngo_spend_details where rid='"+rid+"'";
         
          System.out.println(qry2);
          con = DBConnection.getConnection();
          st = con.createStatement();
        
         
          ResultSet rs2 = st.executeQuery(qry2);
          while(rs2.next()){
             
             det=rid+"#"+rs2.getInt("ngo_id")+"#"+rs2.getString("used_for")+"#"+rs2.getString("amount")+"#"+rs2.getString("tdate")+"#"+rs2.getString("ttime")+"#"+rs2.getString("amount_remaining")+"#"+rs2.getString("hash")+"@@"+det;
             
     
             
          }
        
          return det;
    }
//   public ArrayList get_ngo_fund_details() throws ClassNotFoundException, SQLException{
//        ArrayList al=new ArrayList();
//        
//       
//        String qry2 = "select * from ngo_fund_request_details";
//         
//          System.out.println(qry2);
//          con = DBConnection.getConnection();
//          st = con.createStatement();
//        
//         
//          ResultSet rs2 = st.executeQuery(qry2);
//          while(rs2.next()){
//             al.add(rs2.getInt("rid")+"#"+rs2.getInt("hid")+"#"+rs2.getInt("pid")+"#"+rs2.getInt("tid")+"#"+rs2.getString("expected_amount")+"#"+rs2.getString("rdate")+"#"+rs2.getString("rtime")+"#"+rs2.getString("status")+"#"+rs2.getString("treatment_name")+"#"+rs2.getString("Medicine_Charge")+"#"+rs2.getString("Hospital_Charge")+"#"+rs2.getString("Other_Treatemnt")+"#"+rs2.getString("Doctor_Charge")+"#"+rs2.getString("Surgery")+"#"+rs2.getString("predicted_amount")+"#"+rs2.getString("to_account"));
//             
//     
//             
//          }
//          
//          return al;
//    }
}
