/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

/**
 *
 * @author sumit
 */
public class info {
    public static     String path="D:/AI Fund raiser/Fund_Raise_Patient/web/";
    
    public static     String pname="AI Based Fund Raise using Block Chain";
    public static     String path_py="D:/AI Fund raiser/fund_price_ml/";
   public static     String path_py_ml="D:/AI Fund raiser/fund_price_ml/";
}
