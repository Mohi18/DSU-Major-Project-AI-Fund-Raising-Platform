/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Database.DBQuery;
import Logic.info;
import com.oreilly.servlet.MultipartRequest;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author sumit
 */
public class fund_registration1 extends HttpServlet {
private String newPath="",to_account="",dirName="",paramname="",pid="",pattern="",pattern1="",Path="",expected_amount="",fdata="",tid="";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            HttpSession session=request.getSession();
		dirName =info.path;
                System.out.println("????????????????????????????????"+dirName);
		paramname=null;
                int id=0; 
                byte[] b=null, b1=null,b2=null,b3=null;
                ArrayList list=new ArrayList();
                FileWriter fw=null;
                pid="";
                
                RequestDispatcher rd = null;
       
		
   		  File file = null;
   		  
			
		RequestDispatcher view=null;
		try
                {
			int a=0,s=0,p=0;
                        String abPath="",sPath="",pptpath="";
                        BufferedInputStream  bis = null; 
                        BufferedOutputStream bos = null;
			MultipartRequest multi = new MultipartRequest(request, dirName,	10 * 1024 * 1024); 
                        Enumeration params = multi.getParameterNames();
			while (params.hasMoreElements()) 
			{
				paramname = (String) params.nextElement();
                                
                                 if(paramname.equalsIgnoreCase("category"))
				{
					tid=multi.getParameter(paramname);
				}
                                 
                                  if(paramname.equalsIgnoreCase("approx_cost"))
				{
					expected_amount=multi.getParameter(paramname);
				}
                                   if(paramname.equalsIgnoreCase("to_account"))
				{
					to_account=multi.getParameter(paramname);
				}
                               
                        }
                        String hid=session.getAttribute("uname").toString();
                        System.out.println("hid==========="+hid);
                       
                        String arr[]=fdata.split("#");
                        DBQuery db=new DBQuery();
                        int rid=db.add_fund_details(hid, pid, tid, expected_amount,arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],to_account,arr[7]);
                        System.out.println("..."+rid);
                        session.setAttribute("rid", rid);
                        
                        pattern = "dd-MM-yyyy";
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

                        String tdate = simpleDateFormat.format(new Date());
                        System.out.println(tdate);
                        
                         pattern1 = "hh-mm-ss";
                        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

                        String tdate1 = simpleDateFormat1.format(new Date());
                        tdate1=tdate1.replace(":", "-");
                        System.out.println(tdate1);
                        
                        
                        Path=info.path;
                                
                                File f=new File(Path);
                                if(f.exists()){
                                }
                                else{
                                f.mkdirs();
                                }
                                
                        
			Enumeration files = multi.getFileNames();	
                        while (files.hasMoreElements()) 
                        {
                            paramname = (String) files.nextElement();
                            if(paramname.equals("d1"))
                            {
                                paramname = null;
                            }
                            if(paramname != null && paramname.equals("report"))
                            {
                               s = 1;
                               pptpath = multi.getFilesystemName(paramname);
                               String fPath = dirName+pptpath;
                               System.out.println("report>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+fPath);
                                 if(!fPath.contains("null"))  
                                 {
                                    file = new File(fPath);
                                    FileInputStream fsR = new FileInputStream(file);
                                    b3=new byte[fsR.available()];
                                    list.add(fsR);
                                    System.out.println(info.path_py+rid+".pdf");
                                    newPath=info.path_py+rid+".pdf";
                                    FileOutputStream foutReport=new FileOutputStream(newPath);
                                    int j=0;
                                       while((j=fsR.read())!=-1)
                                       {

                                       foutReport.write((byte)j);

                                       }
                                       fsR.close();
                                       foutReport.close();
                                 }
                              }
                        }
                        
                        
                        rd=request.getRequestDispatcher("fund_registration.jsp");
                        rd.forward(request, response);
                }catch(Exception e)
                {
                e.printStackTrace();
                }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
