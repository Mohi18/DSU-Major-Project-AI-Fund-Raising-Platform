import Database.DBQuery;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;


@WebServlet(name = "UserRegistration", urlPatterns = {"/UserRegistration"})
public class UserRegistration extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
       
        try{
            response.setContentType("text/html;charset=UTF-8");
        
        PrintWriter out = response.getWriter();
        
        
    
        HttpSession session = request.getSession();
        RequestDispatcher rd = null;
        //String id = request.getParameter("u_id");
        String fname    = request.getParameter("txtFname").toString();
        System.out.println("Patient FName = " + fname);
        
        String lname    = request.getParameter("txtLname").toString();
        System.out.println("Patient LName = " + lname);
        
        String phone    = request.getParameter("txtPhone").toString();
        System.out.println("Patient Phone Number = " + phone);
        String email    = request.getParameter("email").toString();
        System.out.println("Patient email id = " + email);
        String add      = request.getParameter("txtAddress").toString();
        System.out.println("Patient Address = " + add);
        
        String doctor_id = request.getParameter("lstDocID").toString();
                  int doc_id = Integer.parseInt(doctor_id); 
                System.out.println("Doctor ID = " + doc_id);
        
        String group    = request.getParameter("lstBldGrp").toString();
        System.out.println("Patient Blood Group = " + group);
        
        String admDate  = request.getParameter("txtAdmsnDate").toString();
        System.out.println("Patient Admission Date = " + admDate);
        
               String docs  = request.getParameter("docs").toString();
        System.out.println("docs = " + docs);
        
        String password = request.getParameter("txtPass").toString();
        String cpasswrd = request.getParameter("txtCPass").toString();    
        
        
            String uid=session.getAttribute("uname").toString();
        DBQuery db = new DBQuery();

        int i = db.addUserData(uid,fname, lname, phone,email, add, docs, group, admDate, password);//doc_id

        if(i>0){
            //JOptionPane.showMessageDialog(null, "Insertion Successful");
          //  authentication_protocol ap=new authentication_protocol();
       //     Random r=new Random();
         //   int nn=r.nextInt(1000);
           // ap.gen_code("pid"+nn+"rpi");
            session.setAttribute("msg", "Patient ID is "+i);
                System.out.println("Added Successful");
                rd=request.getRequestDispatcher("hospital_home.jsp");
                rd.forward(request, response);
           
        }
        
        else{
             session.setAttribute("msg", "Patient Registration Not Successful");
           rd=request.getRequestDispatcher("hospital_home.jsp");
                rd.forward(request, response);
        }
        /*if (i == 1) {
            session.setAttribute("msg", "Registration Successfull");
            rd = request.getRequestDispatcher("UserRegistration.jsp");
            rd.forward(request, response);
        } else {
            session.setAttribute("msg", "Failed");
            rd = request.getRequestDispatcher("UserRegistration.jsp");
            rd.forward(request, response);
        }*/
       
    }catch(Exception e)
    {
        e.printStackTrace();
    }
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            try {
                processRequest(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(UserRegistration.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
        }


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(UserRegistration.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UserRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
