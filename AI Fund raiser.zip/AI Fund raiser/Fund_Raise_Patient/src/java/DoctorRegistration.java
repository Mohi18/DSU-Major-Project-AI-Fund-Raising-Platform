/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import Database.DBQuery;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "DoctorRegistration", urlPatterns = {"/DoctorRegistration"})
public class DoctorRegistration extends HttpServlet {
private String fname="",lname="",email="",mobNo="",gender="",address="",mbbs="",pg="";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
      
        try {
             fname    = request.getParameter("txtFName").toString();
            System.out.println("Doctor First Name = " + fname);
            
             lname    = request.getParameter("txtLName").toString();
            System.out.println("Doctor Last Name = " + lname);
            
             email    = request.getParameter("txtEmailID").toString();
            System.out.println("Doctor EmailID = " + email);
            
             mobNo    = request.getParameter("txtMobNo").toString();
            System.out.println("Doctor Mobile No = " + mobNo);
            
             gender   = request.getParameter("rdbtnGender").toString(); 
            System.out.println("Doctor Gender = " + gender);
            
             address  = request.getParameter("txtAddress").toString();
            System.out.println("Doctor Address = " + address);
            
             mbbs     = request.getParameter("txtMBBS").toString();
            
             pg       = request.getParameter("lstPG").toString();
            
            String password = request.getParameter("txtPass");
            HttpSession  session=request.getSession();
            String uid=session.getAttribute("uname").toString();
            DBQuery db = new DBQuery();
            int i = db.docReg(uid,fname, lname, email, mobNo, gender, address, mbbs + "," + pg, password);
            
            if(i>0){
                System.out.println("DocReg Successful");
                response.sendRedirect("hospital_home.jsp");
            }
            
            else{
                System.out.println("DocReg Not Successful");
                response.sendRedirect("hospital_home.jsp");
            }
        } 
        
        finally {            
            out.close();
        }
     
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } 
        
        catch (ClassNotFoundException ex) {
            Logger.getLogger(DoctorRegistration.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        catch (SQLException ex) {
            Logger.getLogger(DoctorRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } 
        
        catch (ClassNotFoundException ex) {
            Logger.getLogger(DoctorRegistration.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        catch (SQLException ex) {
            Logger.getLogger(DoctorRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
