/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Database.DBQuery;
import Logic.MailSend;
import Logic.info;
import com.oreilly.servlet.MultipartRequest;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author sumit
 */
public class ngo_fund_registration1 extends HttpServlet {
private String newPath="",to_account="",dirName="",paramname="",approx_cost="",category="",pattern="",pattern1="",Path="",expected_amount="",fdata="",tid="";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            HttpSession session=request.getSession();
		dirName =info.path;
                System.out.println("????????????????????????????????"+dirName);
		paramname=null;
                int id=0; 
                byte[] b=null, b1=null,b2=null,b3=null;
                ArrayList list=new ArrayList();
                FileWriter fw=null;
                
                
                RequestDispatcher rd = null;
       
		
   		  File file = null;
   		  
			
		RequestDispatcher view=null;
		try
                {
			int a=0,s=0,p=0;
                        String abPath="",sPath="",pptpath="";
                        BufferedInputStream  bis = null; 
                        BufferedOutputStream bos = null;
			MultipartRequest multi = new MultipartRequest(request, dirName,	10 * 1024 * 1024); 
                        Enumeration params = multi.getParameterNames();
			while (params.hasMoreElements()) 
			{
				paramname = (String) params.nextElement();
                                if(paramname.equalsIgnoreCase("category"))
				{
					category=multi.getParameter(paramname);
				}
                                 if(paramname.equalsIgnoreCase("to_account"))
				{
					to_account=multi.getParameter(paramname);
				}
                                 
                                  if(paramname.equalsIgnoreCase("approx_cost"))
				{
					approx_cost=multi.getParameter(paramname);
				}
                                   
                               
                        }
                        String nid=session.getAttribute("uname").toString();
                        System.out.println("nid==========="+nid);
                        
                        
                       
                       System.out.println("category="+category);
                       System.out.println("approx_cost="+approx_cost);
                       System.out.println("to_account="+to_account);
                    
                        DBQuery db=new DBQuery();
                        int rid=db.add_ngo_fund_details(nid,category,approx_cost,"pending",to_account);
                        System.out.println("..."+rid);
                        session.setAttribute("rid", nid+"_"+rid);
                        
                        pattern = "dd-MM-yyyy";
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

                        String tdate = simpleDateFormat.format(new Date());
                        System.out.println(tdate);
                        
                         pattern1 = "hh-mm-ss";
                        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

                        String tdate1 = simpleDateFormat1.format(new Date());
                        tdate1=tdate1.replace(":", "-");
                        System.out.println(tdate1);
                        
                        
                        Path=info.path;
                                
                                File f=new File(Path);
                                if(f.exists()){
                                }
                                else{
                                f.mkdirs();
                                }
                                
                        
			Enumeration files = multi.getFileNames();	
                        while (files.hasMoreElements()) 
                        {
                            paramname = (String) files.nextElement();
                            if(paramname.equals("d1"))
                            {
                                paramname = null;
                            }
                            if(paramname != null && paramname.equals("report"))
                            {
                               s = 1;
                               pptpath = multi.getFilesystemName(paramname);
                               String fPath = dirName+pptpath;
                               System.out.println("report>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+fPath);
                                 if(!fPath.contains("null"))  
                                 {
                                    file = new File(fPath);
                                    FileInputStream fsR = new FileInputStream(file);
                                    b3=new byte[fsR.available()];
                                    list.add(fsR);
                                    System.out.println(info.path_py+nid+"_"+rid+".pdf");
                                    newPath=info.path_py+nid+"_"+rid+".pdf";
                                    FileOutputStream foutReport=new FileOutputStream(newPath);
                                    int j=0;
                                       while((j=fsR.read())!=-1)
                                       {

                                       foutReport.write((byte)j);

                                       }
                                       fsR.close();
                                       foutReport.close();
                                 }
                              }
                        }
                        File fnew2=new File(info.path_py+"fname.txt");
                        FileWriter fw_new2=new FileWriter(fnew2);
                        fw_new2.write(nid+"_"+rid+".pdf");
                        fw_new2.close();
                        
                        
                        File fnew21=new File(info.path_py+"ngo_donation_details.txt");
                        FileWriter fw_new21=new FileWriter(fnew21);
                        fw_new21.write(nid+"_"+rid+"@@##"+nid+"@@##"+category+"@@##"+expected_amount+"@@##"+to_account);
                        fw_new21.close();
                        
                        
                        File fnew3=new File(info.path_py+"status.txt");
                        FileWriter fw_new3=new FileWriter(fnew3);
                        fw_new3.write("add_ngo_fund_details");
                        fw_new3.close();
                        MailSend ms=new MailSend();
                        
                        ArrayList al=db.get_email();
                        for(int i=0;i<al.size();i++)
                        {
                      //  ms.emailUtility(al.get(i).toString(), "Please fund for requested ID "+rid);
                        
                        }
                        
                        
                        rd=request.getRequestDispatcher("ngo_fund_registration1.jsp");
                        rd.forward(request, response);
                }catch(Exception e)
                {
                e.printStackTrace();
                }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
