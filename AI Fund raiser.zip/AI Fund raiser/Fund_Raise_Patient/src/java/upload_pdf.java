/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import Database.DBQuery;

import Logic.Crypto;

import Logic.MailSend;
import Logic.getFileChecksum;
import Logic.info;
import com.oreilly.servlet.MultipartRequest;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.security.MessageDigest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;

import javax.crypto.Cipher;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Sumit
 */
public class upload_pdf extends HttpServlet {
private String newPath="",dirName="",paramname="",pid="",pattern="",pattern1="",Path="",hash="",fdata="";
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
                ServletContext context = getServletContext();
                HttpSession session=request.getSession();
		dirName =info.path;
                System.out.println("????????????????????????????????"+dirName);
		paramname=null;
                int id=0; 
                byte[] b=null, b1=null,b2=null,b3=null;
                ArrayList list=new ArrayList();
                FileWriter fw=null;
                pid="";
                
                
		
   		  File file = null;
   		  
			
		RequestDispatcher view=null;
		try
                {
			int a=0,s=0,p=0;
                        String abPath="",sPath="",pptpath="";
                        BufferedInputStream  bis = null; 
                        BufferedOutputStream bos = null;
			MultipartRequest multi = new MultipartRequest(request, dirName,	10 * 1024 * 1024); 
                        Enumeration params = multi.getParameterNames();
			while (params.hasMoreElements()) 
			{
				paramname = (String) params.nextElement();
                                if(paramname.equalsIgnoreCase("pid"))
				{
					pid=multi.getParameter(paramname);
				}
                               
                        }
                        String hid=session.getAttribute("hid").toString();
                        System.out.println("hid==========="+hid);
                        pattern = "dd-MM-yyyy";
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

                        String tdate = simpleDateFormat.format(new Date());
                        System.out.println(tdate);
                        
                         pattern1 = "hh-mm-ss";
                        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

                        String tdate1 = simpleDateFormat1.format(new Date());
                        tdate1=tdate1.replace(":", "-");
                        System.out.println(tdate1);
                        
                        
                        Path=info.path;
                                
                                File f=new File(Path);
                                if(f.exists()){
                                }
                                else{
                                f.mkdirs();
                                }
                                
                        
			Enumeration files = multi.getFileNames();	
                        while (files.hasMoreElements()) 
                        {
                            paramname = (String) files.nextElement();
                            if(paramname.equals("d1"))
                            {
                                paramname = null;
                            }
                            if(paramname != null && paramname.equals("report"))
                            {
                               s = 1;
                               pptpath = multi.getFilesystemName(paramname);
                               String fPath = dirName+pptpath;
                               System.out.println("report>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+fPath);
                                 if(!fPath.contains("null"))  
                                 {
                                    file = new File(fPath);
                                    FileInputStream fsR = new FileInputStream(file);
                                    b3=new byte[fsR.available()];
                                    list.add(fsR);
                                    System.out.println(hid+"_"+pid+"_"+tdate+"_"+tdate1+".pdf");
                                    newPath=info.path+hid+"_"+pid+"_"+tdate+"_"+tdate1+".pdf";
                                    FileOutputStream foutReport=new FileOutputStream(newPath);
                                    int j=0;
                                       while((j=fsR.read())!=-1)
                                       {

                                       foutReport.write((byte)j);

                                       }
                                       fsR.close();
                                       foutReport.close();
                                 }
                              }
                        }
        //Use SHA-256 algorithm
        MessageDigest shaDigest;
        
        try {
            //Create checksum for this file
            File fileh = new File(newPath);
            shaDigest = MessageDigest.getInstance("SHA-256");
            //SHA-256 checksum 
            hash = getFileChecksum.getFileHash(shaDigest, fileh);
            System.out.println(">>>"+hash);
            
            File fh=new File(info.path_py+hid+"_"+pid+"_"+tdate+"_"+tdate1+"_hash.txt");
            FileWriter fwh=new FileWriter(fh);
            fwh.write(hash);
            fwh.close();
            
        } catch (Exception ex) {
           ex.printStackTrace();
        }                 
        String key = "This is a secret";
	File inputFile = new File(newPath);
	File encryptedFile = new File(info.path_py+hid+"_"+pid+"_"+tdate+"_"+tdate1+"_enc.pdf");
	//File decryptedFile = new File(info.path_py+hid+"_"+pid+"_"+tdate+"_dec.pdf");
        try {
	     Crypto.fileProcessor(Cipher.ENCRYPT_MODE,key,inputFile,encryptedFile);
	    // Crypto.fileProcessor(Cipher.DECRYPT_MODE,key,encryptedFile,decryptedFile);
	     System.out.println("Sucess");
	 } catch (Exception ex) {
	     System.out.println(ex.getMessage());
             ex.printStackTrace();
	 }    
        
       // inputFile.delete();
        DBQuery db=new DBQuery();
        ArrayList al=db.get_patient_details(hid, pid);
        MailSend ms=new MailSend();
        System.out.println(al.get(3).toString());
       // ms.emailUtility(al.get(3).toString(), key, hid+"_"+pid+"_"+tdate+"_"+tdate1+".pdf");
        db.add_report_details(hid, pid, hid+"_"+pid+"_"+tdate+"_"+tdate1, "Lab Assistant", session.getAttribute("uname").toString(), tdate+"_"+tdate1);
        
        Thread.sleep(2000);
        File fnew=new File(info.path_py+"status.txt");
        FileWriter fw_new=new FileWriter(fnew);
        fw_new.write(hid+"_"+pid+"_"+tdate+"_"+tdate1);
        fw_new.close();
        Thread.sleep(5000);
        
        
        File file1 = new File(info.path_py+"details.txt"); 

        BufferedReader br = new BufferedReader(new FileReader(file1)); 

        String st; 
        while ((st = br.readLine()) != null) {
        System.out.println(st); 
        fdata+=st+"\n";
        }
                    
                    
                    
                     
//                     System.out.println("___________");
//                     System.out.println(fdata);
//                     System.out.println("_______enc_data_____");
//                     String enc_data=AESencrp.encrypt(fdata); 
//                     System.out.println(enc_data);
//                     System.out.println("-----------enc_data----------");
                     
                    
//                     File fnew=new File(Path+hid+"_"+pid+"_"+tdate+"_enc.txt");
//                     FileWriter fw_new=new FileWriter(fnew);
//                     fw_new.write(enc_data);
//                     fw_new.close();
                        
                        
                        
                        
                        
//                    String password = "password123";
//                    String fromFile = Path+hid+"_"+pid+"_"+tdate+".txt"; // from resources folder
//                    String toFile = Path+hid+"_"+pid+"_"+tdate+"_enc.txt";
//                    System.out.println("fromFile="+fromFile);
//                    System.out.println("toFile"+toFile);
                    
                    
                    
                    
        // encrypt file
       // EncryptorAesGcmPasswordFile.encryptFile(fromFile, toFile, password);

                      //  aes_enc_dec aes=new aes_enc_dec();
                        
                      //  aes.encrypt(Path+hid+"_"+pid+"_"+tdate+".pdf", Path+hid+"_"+pid+"_"+tdate+"_enc.pdf");
                       
                        //Logic.getFileChecksum gc=new Logic.getFileChecksum();

                 
        // to store in ipfs
//                    String fdata_enc="";
//                    File file_enc = new File(Path+hid+"_"+pid+"_"+tdate+"_enc.txt"); 
//  
//                    File fd=new File(info.path_ipfs+hid+"_"+pid+"_"+tdate+"_enc.txt");
//                    
//                    copyFileUsingStream(file_enc,fd);
//                    
//                    FileOutputStream fout=null;
//        
//                    String data="ipfs add "+hid+"_"+pid+"_"+tdate+"_enc.txt";
//                    File f1=new File(info.path_ipfs+"test.bat");
//                    fout = new FileOutputStream(f1);
//                    fout.write(data.getBytes());
//                    fout.close();
//            
//            
//                    try {
//
//
//                        File dir = new File(info.path_ipfs);
//                        ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/C", "Start","test.bat");
//                        pb.directory(dir);
//                        Process pp = pb.start();
//
//
//
//                        } catch (IOException ex) {
//                        }
//          
            
          //to store in etherium blockchain  
            
//            FileOutputStream foute=null; 
//            String datae=hid+"_"+pid+"_"+tdate+"_enc.txt"+"_#_"+hash+"_#_ipfs_hash";
//            File fe=new File(info.path_ether+"input.txt");
//            foute = new FileOutputStream(fe);
//            foute.write(datae.getBytes());
//            foute.close();
            
            
            
            
            
            
            
            // decryption test
//  BufferedReader br_enc = new BufferedReader(new FileReader(file_enc)); 
//  
//  String st_enc; 
//  while ((st_enc = br_enc.readLine()) != null) {
//    System.out.println(st_enc); 
//  fdata_enc+=st_enc+"\n";
//  }            
// String dec_data=       AESencrp.decrypt(fdata_enc);
//                    System.out.println(dec_data);
                        
//                        MessageDigest md = MessageDigest.getInstance("MD5");
//        FileInputStream fis = new FileInputStream(Path+hid+"_"+pid+"_"+tdate+"_enc.pdf");
// 
//        byte[] dataBytes = new byte[1024];
// 
//        int nread = 0; 
//        while ((nread = fis.read(dataBytes)) != -1) {
//          md.update(dataBytes, 0, nread);
//        };
//        byte[] mdbytes = md.digest();
// 
//        //convert the byte to hex format method 1
//        StringBuffer sb = new StringBuffer();
//        for (int i = 0; i < mdbytes.length; i++) {
//          sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
//        }
// 
//        System.out.println("Digest(in hex format):: " + sb.toString());
// 
//        //convert the byte to hex format method 2
//        StringBuffer hexString = new StringBuffer();
//    	for (int i=0;i<mdbytes.length;i++) {
//    		String hex=Integer.toHexString(0xff & mdbytes[i]);
//   	     	if(hex.length()==1) hexString.append('0');
//   	     	hexString.append(hex);
//    	}
//    	System.out.println("Digest(in hex format):: " + hexString.toString());
                        
                        
                        
                        String msg="Successfully Uploaded";
                        response.sendRedirect("lab_home.jsp?msg="+msg);
                        
          }catch(Exception e){e.printStackTrace();
          String msg="Exception occured or details already present!!!";
                        response.sendRedirect("lab_home.jsp?msg="+msg);
          }
        }
    
    }
private static void copyFileUsingStream(File source, File dest) throws IOException {
    InputStream is = null;
    OutputStream os = null;
    try {
        is = new FileInputStream(source);
        os = new FileOutputStream(dest);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = is.read(buffer)) > 0) {
            os.write(buffer, 0, length);
        }
    } finally {
        is.close();
        os.close();
    }
}
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
